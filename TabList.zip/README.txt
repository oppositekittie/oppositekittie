This ZIP archive contains software files for all supported platforms.

Each file name includes the name of the platform on which server type it will run.

Bukkit like Spigot/Paper and its forks
Bungee for proxy servers